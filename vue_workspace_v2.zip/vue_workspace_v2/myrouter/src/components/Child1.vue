<template>
  <div class="hello">
    <h1>계산기</h1>
    x : <input v-model="x"><br/>
    y : <input v-model="y"><br/>

    <!-- $event=>$emit 가 부모 컴포넌트의 함수로 요청을 보낸다. 첫번째 매개변수는 함수이름
    , 두번째 부터는 매개변수이다. 
    v-on:click ==> @click 로 바뀐다 -->

    <button v-on:click="$event=>$emit('add', x, y)">더하기</button>
  </div>
</template>

<script>
export default { 
  name: 'Child1Component',
  data: function(){
    return {
      x:0,
      y:0
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
