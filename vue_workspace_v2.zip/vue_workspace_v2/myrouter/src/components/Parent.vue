<template>
  <div class="hello">
    <h1>부모컴포넌트</h1>
    <Child1Component v-on:add="add"/>
    <Child2Component v-bind:result="result"/>
  </div>
</template>

<script>
import Child1Component from './Child1';
import Child2Component from './Child2';

export default {
  name: 'ParentComponent',
  data:function(){
    return{
      result:0
    }
  },
  components:{
    Child1Component, 
    Child2Component
  }, 
  methods:{
    //자식 컴포넌트에서 호출하려고 한다 (이벤트버스를 통해서 부른다 )
    add:function(x, y){
      console.log("dddddd");
      this.result = parseInt(x) + parseInt(y);
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
