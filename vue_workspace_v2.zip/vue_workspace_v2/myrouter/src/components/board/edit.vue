<template>
  <div class="hello">
    <h1>수정</h1>
    이름 : <input v-model="name"> <br/>
    이메일 : <input v-model="email"> <br/>
    <button type="button" v-on:click="updateItem">수정</button>
  </div>
</template>

<script>
export default {
  name: 'EditComponent',
  data:function(){
    return{
      id:0,
      name:"",
      email:""
    }
  },
  created:function(){
    this.getItem();
  },
  methods:{
    getItem:function(){
        console.log( this.$route.params.id);

        let url="http://localhost:4000/data/"+ this.$route.params.id;
        this.axios.get(url)
        .then( (res)=>{
          console.log( res);
          this.id = res.data.id; 
          this.name = res.data.name;
          this.email = res.data.email;
        })
        .catch((error)=>{
          console.log( error);
        })
    },

    updateItem:function(){
      let temp = {"id":this.id, name:this.name, email:this.email};
      let url = "http://localhost:4000/data/"+ this.$route.params.id
      this.axios.put(url, temp)
      .then(res=>{
        console.log( res );
        this.$router.push("/board");  //redirect호출하면 다시 화면을 불러온다. 
                                          //스므스하게 체인지를 하자 
      })
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
