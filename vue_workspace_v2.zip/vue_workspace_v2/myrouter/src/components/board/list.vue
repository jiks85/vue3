<template>
  <div class="hello">
    <h1>목록</h1>
    <table class="table table-hover">
      <thead>
        <tr>
          <th>번호</th>
          <th>제목</th>
          <th>작성자</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="item in items" :key="item.id">
            <td>{{item.id}}</td>
            <td>{{item.name}}</td>
            <td>{{item.email}}</td>
            <td>
              <router-link :to="{name:'Edit', params:{id:item.id}}">수정</router-link>
            </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
export default {
  name: 'ListComponent',
  data:function(){
    return {
      items:[],  //데이터 배열 
      totalCnt:0 //전체 레코드수 0 
    }
  }
  , 
  created:function(){
    console.log( "객체가 생성될때 자동으로 호출된다.");
    this.fetchItems(); //초기화 작업하고자 할때 적절한 위치 
  },
  methods:{
    fetchItems:function(){
      //여기서 백앤드 서버와 통신을 해야 한다 우선 백앤드 서버가 없어서 가짜 데이터를 넣어놓는다 
      /*this.items.push({id:1, title:"제목1", contents:"내용1", writer:"작성자1"});
      this.items.push({id:2, title:"제목1", contents:"내용1", writer:"작성자1"});
      this.items.push({id:3, title:"제목1", contents:"내용1", writer:"작성자1"});
      this.items.push({id:4, title:"제목1", contents:"내용1", writer:"작성자1"});
      this.items.push({id:5, title:"제목1", contents:"내용1", writer:"작성자1"});
      this.items.push({id:6, title:"제목1", contents:"내용1", writer:"작성자1"});*/
      let url = "http://localhost:4000/data";
      //axios는 비동기 통신을 한다. 그래서 데이터를 리턴- promise로 구축되었음 
      //
      this.axios.get(url)
      .then( (response)=>{
          console.log( response );
          this.items = response.data;
         
      })
      .catch((error)=>{
        console.log( error);
      });

      //let result = await axios.get(url);

      //axios 라이브러리고 바꿀 예정 
      
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
