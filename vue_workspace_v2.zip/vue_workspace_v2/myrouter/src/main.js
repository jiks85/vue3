import Vue from 'vue'
import App from './App.vue'
import VueRouter from 'vue-router' //node-modules  폴더에 있는 라이브러리는 경로를 지정하지 않는다
import IndexComponent from './components/Index.vue'
import AboutComponent from './components/About.vue'
import ParentComponent from './components/Parent.vue'
import ListComponent from './components/board/list.vue'
import EditComponent from './components/board/edit.vue'
import 'bootstrap/dist/css/bootstrap.min.css'
import VueAxios  from 'vue-axios'
import axios from 'axios';

//Vue인스턴스가 VueRouter쓴다고 해야 한다. - 미들웨어 
Vue.use(VueRouter);
Vue.use(VueAxios, axios)  //미들웨어 추가하기 
Vue.config.productionTip = false

//url -> 연결될 컴포넌트 정보를 저장한다 
const routes = [
  {name:"Index", path:"/", component:IndexComponent},
  {name:"About", path:"/about", component:AboutComponent},
  {name:"Parent", path:"/calc", component:ParentComponent},
  {name:"BoardList", path:"/board", component:ListComponent},
  {name:"Edit", path:"/board/edit", component:EditComponent},
];

//path 에 전달값이 url이다.  component :사용될 컴포넌트 정보 두개의 이름이 Index임 

const router = new VueRouter({mode:'history', routes:routes});


new Vue({
  render: h => h(App), router   //****************  연결방식이 2하고 3하고 다르다 */
}).$mount('#app')

/*

가급적 cmd 화면은 관리자권한으로 열자 
라우팅 --   url -> 동작될 컴포넌트가 뭐냐를 지정한다 
npm install vue-router@3.4.8
npm install bootstrap  버전 5부터 jquery 가 없어짐
npm install axios        ajax담당 라이브러리 
npm install vue-axios 

*/