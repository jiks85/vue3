<template>
  <div class="hello">
    <h1>{{ msg }}</h1>
  </div>
</template>

<script>

//angular - 양방향(부모, 자식간에), vue, react - 부모 -> 자식, 자식 -> 부모 (안된다.)
export default {
  name: 'HelloWorld',
  props: {         //props : 부모컴포넌트로부터 값을 받아올 경우에 props로 받아온다 
    msg: String
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
