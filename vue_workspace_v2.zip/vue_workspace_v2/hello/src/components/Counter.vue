<template>
    <h1>{{count}}</h1>
    <button @click="count++">증가</button>
    <button @click="count--">감소</button>
</template>

<script>
export default {
    name: 'CounterComponent',   //Vue2에서는컴포넌트이름 한단어 
                                 //Vue3에서는 멀티워드로 
    data(){
        return {
            count:0
        }
    }
}
</script>

<style>
    h1{
        color:#0000ff;
    }
</style>
