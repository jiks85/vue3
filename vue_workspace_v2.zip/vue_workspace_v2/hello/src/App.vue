<template>
  <img alt="Vue logo" src="./assets/logo.png">
  <h1>Hello Vue</h1>
  <HelloWorld msg="안녕하세요" /> <!-- 컴포넌트는 template에서 태그로 바뀐다. -->
  <CounterComponent/>
  <CounterComponent/>
  <CounterComponent/>

</template>

<script>
import HelloWorld from './components/HelloWorld.vue'
import CounterComponent from './components/Counter.vue'

export default {
  name: 'App',   //import App from './App.vue' App.vue파일에 있는 App 를 갖고 와라
  components: {
    HelloWorld,
    CounterComponent    
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
