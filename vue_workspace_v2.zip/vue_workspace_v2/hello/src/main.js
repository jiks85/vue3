import { createApp } from 'vue'  //라이브러리 import 한다 .
import App from './App.vue'      //App.vue

//뷰 인스턴스 생성시 매개변수로 기본 컴포넌트 
//mount - index.html이 <div id="app"></div>
createApp(App).mount('#app')
