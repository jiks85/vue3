package com.example.demo.board;

public class BoardService {

}
