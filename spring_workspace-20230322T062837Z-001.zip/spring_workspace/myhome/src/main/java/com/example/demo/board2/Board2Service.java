package com.example.demo.board2;

public class Board2Service {

}
