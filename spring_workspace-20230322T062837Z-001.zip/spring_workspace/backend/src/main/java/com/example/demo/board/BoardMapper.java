package com.example.demo.board;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;



public interface BoardMapper {
	
	
	 //@Select("SELECT * FROM CITY WHERE state = #{state}")
	  //City findByState(@Param("state") String state);
	 
	List<BoardDto> getList();
	/*BoardDto getView(int id);
	
	void update(BoardDto dto) {
		int pos = list.indexOf(dto);
		if (pos !=-1)
			list.set(pos, dto);
	}
	
	void delete(BoardDto dto) {
		int pos = list.indexOf(dto);
		if (pos !=-1)
			list.remove(pos);
	}
	
	void insert(BoardDto dto) {
		int id = list.get(list.size()-1).getId();
		dto.setId( id+1);
		list.add(dto);
	}*/
}
