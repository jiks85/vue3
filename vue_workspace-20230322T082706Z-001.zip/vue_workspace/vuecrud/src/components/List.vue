<template>
  <div class="hello">
    <h1>목록 {{totalCount}}</h1>
    
    <img src ="http://localhost:4000/image"/>
    <table class="table table-hover">
      <thead>
        <th>번호</th>
        <th>제목</th>
        <th>작성자</th>
       
        <th>수정/삭제</th>
      </thead>
      <tbody>
        <tr v-for="item in items" :key="item.id">
          <td>{{item.id}}</td>
          <td>{{item.title}}</td>
          <td>{{item.writer}}</td>
      
          <td>
            <router-link :to="{name:'Edit', params:{id:item.id} }" class="btn btn-primary">Edit</router-link>
          </td>
        </tr>
      </tbody>

    </table>
  </div>
</template>

<script>
export default {
  name: 'ListBoard',
  data(){
    return {
      items:[],
      totalCount:0
    }
  },
  created:function(){
    this.fetchItems();
  },
  methods:{
    fetchItems:function(){
      //비동기 통신을 해서 데이터를 가져온다 
      this.items.push({id:1, title:'제목1', contents:'내용1', writer:'홍길동', wdate:'2020-11-04'});
      this.items.push({id:1, title:'제목1', contents:'내용1', writer:'홍길동', wdate:'2020-11-04'});
      this.items.push({id:1, title:'제목1', contents:'내용1', writer:'홍길동', wdate:'2020-11-04'});
      this.items.push({id:1, title:'제목1', contents:'내용1', writer:'홍길동', wdate:'2020-11-04'});
      this.items.push({id:1, title:'제목1', contents:'내용1', writer:'홍길동', wdate:'2020-11-04'});
      this.items.push({id:1, title:'제목1', contents:'내용1', writer:'홍길동', wdate:'2020-11-04'});
      this.items.push({id:1, title:'제목1', contents:'내용1', writer:'홍길동', wdate:'2020-11-04'});
      this.items.push({id:1, title:'제목1', contents:'내용1', writer:'홍길동', wdate:'2020-11-04'});
      
      //let url="http://localhost:8080/guestbook/list";
      let url="http://localhost:3000/guestbook";
      this.axios.get(url)
      .then( (response)=>{
          this.items = response.data["data"];
          this.totalCount = response.data["totalCount"];
      });
    }
  } 
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
