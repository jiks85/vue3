<template>
  <div class="container">
    <div class="card">
        <div class="card-header">
          <h3>등록</h3>
        </div>

        <div class="card-body">
          <form v-on:submit.prevent="updateItem">
              <div class="form-group">
                  <label>title</label>
                  <input type="text" class="form-control" v-model="title"/>
              </div>
              <div class="form-group">
                  <label>writer</label>
                  <input type="text" class="form-control" v-model="writer"/>
              </div>
              <div class="form-group">
                  <label>contents</label>
                  <textarea rows="4" cols="30" class="form-control" v-model="contents" />
              </div>
              <div class="form-group">
                  <input type="submit" class="btn btn-primary" value="수정"/>
              </div>
          </form>
        </div>
    </div> 
  </div>
</template>

<script>
export default {
  name: 'EditBoard',
  data(){
    return{
      id:0,
      title:"",
      writer:"",
      contents:""
    }
  },

  created:function(){
      this.getItem();
  }
  ,
  methods:{
    getItem(){
        let url='http://localhost:3000/guestbook/view/' + this.$route.params.id; 
        console.log(url);
        this.axios.get(url)
        .then( (response)=>{
            console.log(response.data);
            this.id = response.data.id; 
            this.title = response.data.title; 
            this.writer = response.data.writer; 
            this.contents = response.data.contents; 
        });
    },

    updateItem(){
      console.log(this.title);
      
      let temp={id:this.id, title:this.title, writer:this.writer, contents:this.contents};
      //let url="http://localhost:8080/guestbook/insert";
      let url="http://localhost:3000/guestbook/update";
      this.axios.post(url, temp)
                .then( (response)=>{
                  console.log( response );

                  //새로고침 
                  this.$router.push("/List"); //컴포넌트 바뀌치기 - redirect 없습니다
                });

    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
