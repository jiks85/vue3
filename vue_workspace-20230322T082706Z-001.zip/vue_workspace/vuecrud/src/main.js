import { createApp } from 'vue'
import App from './App.vue'



import { createRouter, createWebHistory } from 'vue-router'
import VueAxios from 'vue-axios';
import axios from 'axios';
import CreateBoard from './components/Create.vue';
import EditBoard from './components/Edit.vue';
import ListBoard from './components/List.vue';
import IndexCom from './components/Index.vue';


import '../node_modules/bootstrap/dist/css/bootstrap.min.css';

const routes=[
    {name:'Create', path:'/create',  component:CreateBoard},
    {name:'List',   path:'/list',    component:ListBoard},
    {name:'Edit',   path:'/edit',    component:EditBoard},
    {name:'Index',  path:'/',        component:IndexCom}
  ];
  

const router = createRouter({
    history: createWebHistory(),
    routes
});

const app = createApp(App)
app.use(router)  // 라우터 사용
app.use(VueAxios, axios);
app.mount('#app');