<!-- Calclator.vue --->
<template>
  <div class="hello">
    <h1>계산기</h1>
    x : <input type="text" v-model="x"><br/>
    y : <input type="text" v-model="y"><br/><br/>
    <button v-on:click="$emit('add', x, y)">더하기</button>
  </div>
</template>

<script>
export default {
  name: 'CalculatorComponent',
  data:function(){
      return {
          x:0,
          y:0
      }
  },
  methods:{
      add:function(){
          alert(this.x + this.y); 
      }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
