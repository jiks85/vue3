import { createApp } from 'vue'
import App from './App.vue'



import { createRouter, createWebHistory } from 'vue-router'

import IndexComponent from './components/Index.vue';
import AboutComponent from './components/About.vue';
import GuestbookComponent from './components/Guestbook.vue';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';

const routes =[
  {name:'Index', path:"/", component:IndexComponent},
  {name:'About', path:"/about", component:AboutComponent},
  {name:'Guestbook', path:"/guestbook/:id", component:GuestbookComponent},
];

const router = createRouter({
    history: createWebHistory(),
    routes
});

const app = createApp(App)
app.use(router)  // 라우터 사용
app.mount('#app');