<template>
  <div class="hello">
    <h1>Guestbook {{$route.params.id}} Vue </h1>
    <Calculator v-on:add="add"></Calculator>
    <Calculatorview v-bind:result="result" ></Calculatorview>
  </div>
</template>

<script>
import Calculator from './Calculator.vue';
import Calculatorview from './Calculatorview.vue';
export default {
  name: 'Gustbook',
  data:function(){
    return{
      result:0
    }
  }
  ,
  components:{
    Calculator,
    Calculatorview
  },
  methods:{
    add:function(x, y){
      
      this.result = parseInt(x) + parseInt(y);
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
