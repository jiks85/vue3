<template>
  <div id="app" class="container">
    <nav class="navbar navbar-expand-sm bg-light">
        <ul class="navbar-nav">
          <li class="nav-item"><router-link :to="{name:'Index'}" class="nav-link">Home</router-link></li>
          <li class="nav-item"><router-link :to="{name:'About'}" class="nav-link">About</router-link></li>

          <li class="nav-item"><router-link :to="{name:'Guestbook', params:{id:'1'}}" class="nav-link">Guestbook 1</router-link></li>
          <li class="nav-item"><router-link :to="{name:'Guestbook', params:{id:'2'}}" class="nav-link">Guestbook 2</router-link></li>
          <li class="nav-item"><router-link :to="{name:'Guestbook', params:{id:'3'}}" class="nav-link">Guestbook 3</router-link></li>

        </ul>
    </nav>

    <!--화면 파트 -->
    <transition name="fade">
      <div class="gap">
        <router-view></router-view>
      </div>
    </transition>

  </div>
</template>

<script>
export default {
  name: 'App',
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
