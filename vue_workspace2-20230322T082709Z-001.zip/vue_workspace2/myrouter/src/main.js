/*import Vue from 'vue'
import App from './App.vue'

Vue.config.productionTip = false

new Vue({
  render: h => h(App),
}).$mount('#app')
*/

import Vue from 'vue'
import VueRouter from 'vue-router';
import App from './App.vue'
import Index from './components/Index.vue';
import About from './components/About.vue';
import Guestbook from './components/Guestbook.vue';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';

//라우터 사용을 지정하고 
Vue.use(VueRouter)

Vue.config.productionTip = false

const routes =[
  {name:'Index', path:"/", component:Index},
  {name:'About', path:"/about", component:About},
  {name:'Guestbook', path:"/guestbook/:id", component:Guestbook},
  
];

const router = new VueRouter({mode:'history', routes:routes})
new Vue({
  render: h => h(App), router
}).$mount('#app')