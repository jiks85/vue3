<template>
  <div id="app" class="container">
    <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
      <ul class="navbar-nav">
        <li class="nav-item active">
          <router-link :to="{name:'Index'}" class="nav-link">Home</router-link>
        </li>
        <li class="nav-item">
          <router-link :to="{name:'List'}" class="nav-link">List</router-link>
        </li>
        <li class="nav-item">
          <router-link :to="{name:'Create'}" class="nav-link">Create</router-link>
        </li>
        <li class="nav-item">
          <a class="nav-link disabled" href="#">Disabled</a>
        </li>
      </ul>
    </nav>

    <transition name="fade">
      <div class="gap" style="margin-top:20px">
        <router-view></router-view>
      </div>
    </transition>

  </div>
</template>

<script>

export default {
  name: 'App'
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
