import Vue from 'vue'
import VueRouter from 'vue-router';
import VueAxios from 'vue-axios';
import axios from 'axios';

import App from './App.vue'
import Create from './components/Create.vue';
import Edit from './components/Edit.vue';
import List from './components/List.vue';
import Index from './components/Index.vue';

//부트스트랩 
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';

//라우팅 : node에서는 특정 url과 함수를 묶는다 
//미들웨어 : 중간 중간 필요한 라이브러리들을 끼워넣기 끼워넣어지는 라이브러리를 미들웨어라고 한다 
Vue.use(VueRouter);
Vue.use(VueAxios, axios);

Vue.config.productionTip = false

const routes=[
  {name:'Create', path:'/create',  component:Create},
  {name:'List',   path:'/list',    component:List},
  {name:'Edit',   path:'/edit',    component:Edit},
  {name:'Index',  path:'/',        component:Index}
];

const router = new VueRouter( {mode:'history', routes:routes} );

new Vue({
  render: h => h(App), router 
}).$mount('#app')
